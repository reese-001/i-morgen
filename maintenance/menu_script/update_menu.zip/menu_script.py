import update_menu as um

# um.iterate_bucket_items('www.i-morgen.link')
um.test()

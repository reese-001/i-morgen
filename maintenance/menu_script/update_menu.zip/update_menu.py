import os
from bs4 import BeautifulSoup
import boto3
import codecs
from datetime import datetime


exclusion_list = ['menu.html', "status.html"]
s3 = boto3.client('s3')
logs = boto3.client('logs')


def test():
    source_artifacts = "source-artifacts/"
    build_artifacts = "build-artifacts/"

    with open(os.path.join(build_artifacts, filename), 'w', encoding='utf-8') as f:
        print("saving", dirpath, filename)
        f.write("Hi!")


    for dirpath, dirnames, filenames in os.walk(source_artifacts):

    # Loop through each HTML file in the directory
        for filename in os.listdir(dirpath):
            if filename.endswith('html') and filename not in exclusion_list:
                # Read in the contents of the HTML file
                with open(os.path.join(dirpath, filename), 'r', encoding='utf-8', errors="ignore") as f:
                    html_contents = f.read()
               

                with open(os.path.join(build_artifacts, filename), 'w', encoding='utf-8') as f:
                    print("saving", dirpath, filename)
                    f.write(str(html_contents))


            break


def iterate_bucket_items(bucket):
    clear_failures(bucket)
    response = s3.list_objects_v2(Bucket=bucket)
    count = 0
    for obj in response['Contents']:
        key = obj['Key']
        print("Reviewing file", key)
        template_menu_contents = get_template(bucket)
        if key.endswith('.html') and not key.startswith('templates') and key not in exclusion_list:

            print(key)
            obj = s3.get_object(Bucket=bucket, Key=key)
            body = obj['Body'].read().decode('utf-8')
            soup = BeautifulSoup(body, 'html.parser')
        
            existing_menu = soup.find('div', {'class': 'page-header-fixed page-sidebar-fixed'})

            new_menu = BeautifulSoup(template_menu_contents, 'html.parser').find('div', {'class': 'page-header-fixed page-sidebar-fixed'})
            if new_menu and existing_menu:
                existing_menu.replace_with(new_menu) 
                s3.put_object(Bucket=bucket, Key=key, Body=soup.prettify(formatter=None), ContentType='text/html')
     
                count += 1
            else:
                log_failures(bucket, key)
                
    update_history(bucket, count)

def get_template(bucket):

    template_menu_file = 'templates/menu.html'
    obj = s3.get_object(Bucket=bucket, Key=template_menu_file)
    return obj['Body'].read().decode('utf-8')

def update_history(bucket, count):
    response = logs.put_log_events(
        logGroupName="i-morgen/build",
        logStreamName="update_menu.py",
        logEvents=[
            {
                'timestamp': datetime.now(),
                'message': f"Files Updates: {str(count)}"
            }
        ]
    )


    print("Writing Summary:", str(datetime.now()) + ":  Files Updates: " + str(count))
    key_status = "status.html"
    body_status = s3.get_object(Bucket=bucket, Key=key_status)
    body_status = body_status['Body'].read().decode('utf-8')
    soup_status = BeautifulSoup(body_status, 'html.parser')

    history = soup_status.find('div', {'class': 'history'})
    history.append("<a>" + str(datetime.now()) + ":  Files Updates: " + str(count) + "</a><br/>")
    s3.put_object(Bucket=bucket, Key=key_status, Body=soup_status.prettify(formatter=None), ContentType='text/html')      


def log_failures(bucket, key):
    print("Failure on", key)
    key_status = "status.html"
    body_status = s3.get_object(Bucket=bucket, Key=key_status)

    body_status = body_status['Body'].read().decode('utf-8')

    soup_status = BeautifulSoup(body_status, 'html.parser')

    failed_menu_updates = soup_status.find('div', {'class': 'failed_menu_updates'})
    failed_menu_updates.append("<br/>" + key + " at " + str(datetime.now()))

    s3.put_object(Bucket=bucket, Key=key_status, Body=soup_status.prettify(formatter=None), ContentType='text/html')

def clear_failures(bucket):
    key_status = "status.html"
    body_status = s3.get_object(Bucket=bucket, Key=key_status)

    body_status = body_status['Body'].read().decode('utf-8')

    soup_status = BeautifulSoup(body_status, 'html.parser')

    failed_menu_updates = soup_status.find('div', {'class': 'failed_menu_updates'})
    failed_menu_updates.clear()

    s3.put_object(Bucket=bucket, Key=key_status, Body=soup_status.prettify(formatter=None), ContentType='text/html')